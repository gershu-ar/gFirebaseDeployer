gFirebaseDeployer v1.0

(ENGLISH)
For information, support and feedback go to:
https://github.com/gershu-ar/gFirebaseDeployer/

(ESPAÑOL)
Por información, soporte o comentarios dirígite a:
https://github.com/gershu-ar/gFirebaseDeployer/